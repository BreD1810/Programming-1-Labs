public class Food 
{
	
	private String name;
	
	/*Create the food with a name*/
	Food(String name)
	{
		this.name = name;
	}
	
	/*Return the name*/
	public String getName()
	{
		return name;
	}
}
