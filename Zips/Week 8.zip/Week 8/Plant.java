public class Plant extends Food
{
	
	/*Create the plant food with a name*/
	Plant(String name)
	{
		//Execute the Food classes constructor
		super(name);
	}
	
}
