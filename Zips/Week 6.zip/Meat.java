public class Meat extends Food
{

	/*
	 * Create the meat food with a name
	 */
	Meat(String name)
	{
		//Execute the Food constructor
		super(name);
	}
	
}
